package gui;

import java.time.LocalDate;

import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Pane;
import model.Konference;

public class Konf {
	
	Pane PK = new Pane();
	
	private void initContent(Pane PK) {
      	
       	ListView<Konference> lw1 = new ListView<>();
       	
       	Konference k1 = new Konference("her", 1000, LocalDate.now(), LocalDate.of(2018, 11, 15), "Ko");
       	lw1.getItems().setAll(k1);
       	
       	lw1.setPrefWidth(200);
       	lw1.setPrefHeight(200);
       
	    PK.getChildren().add(lw1);

	}
}
