package gui;

import gui.Konf;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Separator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Konference;

public class mainApp extends Application {

	public static void main(String[] args) {
		Application.launch(args);

	}
	
	@Override
	public void start(Stage stage) {
		    stage.setTitle("KAS");
		    TabPane TP = new TabPane();
		    //Pane PK = new Pane();
		    this.initContent(TP);
		    
		    
	        //  TP.getChildrenUnmodifiable().add(lw1);
	        Scene scene = new Scene(TP, 700, 450);
	        stage.setResizable(false);
	        stage.setScene(scene);
	        stage.setResizable(false);
	        stage.show();
	        
	}
	//--------------------------------------------------
	        
	private void initContent(TabPane TP) {
			          	
	       	ListView<Konference> lw1 = new ListView<>();
	       	
	       	Konference k1 = new Konference("her", 1000, LocalDate.now(), LocalDate.of(2018, 11, 15), "Ko");
	       	lw1.getItems().setAll(k1);
	       	
	       	lw1.setPrefWidth(200);
	       	lw1.setPrefHeight(200);
		    Tab tp1 = new Tab();
		    Tab tp2 = new Tab();
		    Tab tp3 = new Tab();
		    Tab tp4 = new Tab();
		    Tab tp5 = new Tab();
		    tp1.setText("Arrangør");
		    tp2.setText("Konferencer");
		    tp3.setText("Hoteller");
		    tp4.setText("Udflugter");
		    tp5.setText("Ledsager");
	       
		    TP.getTabs().addAll(tp2, tp3, tp5, tp4);
		    
//		    TP.getChildrenUnmodifiable().add(lw1);
	        //controller.reset();
	}
		
	

}
