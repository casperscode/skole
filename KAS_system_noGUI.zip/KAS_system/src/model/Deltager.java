package model;

import java.util.ArrayList;

import model.Ledsager;

public class Deltager {
	
	private String navn;
	private String adresse;
	private String firma;
	private boolean foredragsholder;
	private Ledsager ledsager;
	private int status;
	private ArrayList<Konference> konferencer = new ArrayList<>();
	private Tilmelding tur;
	
	public Deltager(String navn, String adresse, String firma, boolean foredragsholder, Ledsager ledsager, int status) {
		this.navn = navn;
		this.adresse = adresse;
		this.firma = firma;
		this.foredragsholder = foredragsholder;
		this.ledsager = ledsager;
		this.status = status;
	}
	
	public void setKonferencer(Konference konference) {
		konferencer.add(konference);		
	}
	
	public void removeKonference(Konference konference) {
		konferencer.remove(konference);
	}
	
	public Tilmelding getTilmelding() {
		return tur;
	}

}
