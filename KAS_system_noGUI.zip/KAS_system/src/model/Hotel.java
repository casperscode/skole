package model;

import java.util.ArrayList;

public class Hotel {
	private String navn;
	private String adresse;
	private double pris;
	private double prisDouble;
	private final ArrayList<ExtraService> services = new ArrayList<>();

	public Hotel(String navn, String adresse, double pris, double prisDouble) {
		this.navn = navn;
		this.adresse = adresse;
		this.pris = pris;
		this.prisDouble = prisDouble;
	}

	public String toString() {
		return "" + navn + adresse + pris + prisDouble;

	}

	public ArrayList<ExtraService> getservices() {
		return new ArrayList<>(services);
	}

	public void addExtraservice(ExtraService service) {
		if (!services.contains(service)) {
			Pre.require(service.getHotel() == null);
			services.add(service);
			service.setHotel(this);
		}
	}

}
