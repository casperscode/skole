package model;

import java.time.LocalDate;
import java.util.ArrayList;
import storage.Storage;


public class Konference {

	private static String lokation;
	private static int pris;
	private static LocalDate startDato;
	private static LocalDate slutDato;
	private static String navn;
	private static Tilmelding tur;
//	private static final ArrayList<Arrangør> Konferencer = new ArrayList<>();
//	private static final ArrayList<Hotel> Hoteller = new ArrayList<>();
//	private static final ArrayList<Udflugt> Udflugter = new ArrayList<>();
//	private static final ArrayList<Deltager> Deltagere = new ArrayList<>();
	
	public Konference(String lokation, int pris, LocalDate startDato, LocalDate slutDato, String navn) {
		Pre.require(pris >= 0);
		Pre.require(startDato.isBefore(slutDato));
		Pre.require(navn != null && lokation != null);
		
		this.lokation = lokation;
		this.pris = pris;
		this.startDato = startDato;
		this.slutDato = slutDato;
		this.navn = navn;
		
	}
	
	public String toString() {
		String returString = "Konference: \n" + "Adresse: "+ lokation +"\nPris: "+ pris+"\nDato: " + startDato +" "+ slutDato + "\nNavn: "+navn;
		return returString;
	}
	
}
