package model;

import java.util.ArrayList;

public class Ledsager {
	private String navn;
	private String adresse;
	private Deltager deltager;
	private ArrayList<Udflugt> tilmeldtUdflugter = new ArrayList<>();

	Ledsager(String navn, String adresse, Deltager deltager) {
		Pre.require(navn != null && adresse != null && deltager != null);
		this.navn = navn;
		this.adresse = adresse;
		this.deltager = deltager;
	}

	public static void DeltagUdflugt(Udflugt udflugt) {
		Udflugt.addLedsager(null);
	}

	public void AfmeldUdflugt(Udflugt udflugt) {
		Udflugt.removeLedsager(this);
	}
}
