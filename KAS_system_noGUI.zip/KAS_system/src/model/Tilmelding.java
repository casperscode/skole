package model;

import model.Hotel;

import java.util.ArrayList;

import model.ExtraService;

public class Tilmelding {

	private Hotel hotel;
	private Deltager delt;
	private Konference konf;
	private ArrayList<ExtraService> extra = new ArrayList<>();
	
	public Tilmelding(Hotel hotel) {
		this.hotel = hotel;
	}
	
	public void setExtras(ExtraService extra) {
		this.extra.add(extra);
	}
	
	public ArrayList<ExtraService> getExtras() {
		return extra;
	}
	
	public Hotel getHotel() {
		return hotel;
	}

}