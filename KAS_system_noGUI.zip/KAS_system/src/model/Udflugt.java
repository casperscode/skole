package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Udflugt {
	private String lokation;
	private LocalDate tid;
	private static ArrayList<Ledsager> DeltagendeLedsagere = new ArrayList<>();
	private String navn;
	private Konference konference;

	Udflugt(String Lokation, LocalDate tid, String navn, Konference konference) {
		Pre.require(navn != null && Lokation != null);
		Pre.require(konference != null);

		this.lokation = Lokation;
		this.tid = tid;
		this.navn = navn;
		this.konference = konference;
	}

	public String toString() {
		String returnString = "Udflugt: \n" + "Navn: " + navn + " " + lokation;
		return returnString;
	}

	public static ArrayList<Ledsager> getTilmeldte(Udflugt udflugt) {
		return DeltagendeLedsagere;
	}

	public static void addLedsager(Ledsager ledsager) {
		Pre.require(ledsager != null);
		DeltagendeLedsagere.add(ledsager);
	}

	public static void removeLedsager(Ledsager ledsager) {
		Pre.require(ledsager != null);
		DeltagendeLedsagere.remove(ledsager);
	}

}
