package tests;

import java.time.LocalDate;

import model.Konference;
import storage.Storage;

public class test1 {
	
	public static void main(String[] args) {
		

		Konference k1 = new Konference("vej", 50, LocalDate.now(), LocalDate.of(2018, 11, 14), "John");
		

		Storage.addKonference(k1);
	    System.out.println(Storage.getKonferencer().toString());
		
		
	}
	

}
